import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable ,throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiCallServiceService {

  constructor(private httpCall : HttpClient) { }

  BackEnd_URL = 'http://127.0.0.1:8000';

  readData():Observable<any>
  {
    return this.httpCall.get(`${this.BackEnd_URL}/read.php`);
  }

  createData(inputData):Observable<any>
  {
    return this.httpCall.post(`${this.BackEnd_URL}/create.php`,inputData);
  }

  updateData(inputData):Observable<any>
  {
    return this.httpCall.put(`${this.BackEnd_URL}/update.php`,inputData);
  }

  deleteData(inputId):Observable<any>
  {
    return this.httpCall.delete(`${this.BackEnd_URL}/delete.php?id=${inputId}`);
  }
}
