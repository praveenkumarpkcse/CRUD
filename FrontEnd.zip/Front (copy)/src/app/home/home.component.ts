import { Component, OnInit } from '@angular/core';
import { ApiCallServiceService } from '../api-call-service.service';
import { Router } from '@angular/router';
import { FormGroup , FormControl , FormBuilder ,Validator, Validators} from '@angular/forms';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  OutputData = [];
  Empty:boolean = false;
  CreateForm :boolean = false;
  EmpData : FormGroup;
  EditFlag :boolean = false;
  submitted = false;

  constructor( public ApiCall : ApiCallServiceService , 
               public router : Router,
               public fb : FormBuilder ) { }

  ngOnInit() {
    this.EmpData = this.fb.group({
      EmpId:[''],
      Empname:['',[Validators.required]],
      EmpJob:['',[Validators.required]],
      EmpExp:['',[Validators.required]]
    });

    this.ApiCall.readData().subscribe(res =>{
      this.OutputData = res;
      if(this.OutputData.length <= 0){
        this.Empty = true;
      }
    });
  }

  createForm(){
    this.submitted = true;
    if(this.EmpData.invalid){
      return false;
    }

    this.ApiCall.createData(this.EmpData.value).subscribe(res=>{
      if(res){
        this.CreateForm = false;
        alert("Successfully Stored");
        this.router.navigate(['/Home'])
        .then(() => {
          window.location.reload();
        });
      }
    },(error)=>{
      alert(error);
    });
  }

  updateForm(){
    this.submitted = true;
    if(this.EmpData.invalid){
      return false;
    }

    this.ApiCall.updateData(this.EmpData.value).subscribe(res=>{
      console.log(res);
      if(res){
        this.CreateForm = false;
        alert("Successfully Updated");
        this.router.navigate(['/Home'])
        .then(() => {
          window.location.reload();
        });
      }
    });
  }

  createEmp(){ 
    this.CreateForm = true;
  }

  EditEmp(InputData){
    this.CreateForm = true;
    this.EditFlag = true;
    this.submitted = true;

    this.EmpData.patchValue({
      EmpId:InputData.id,
      Empname:InputData.EmpName,
      EmpJob:InputData.EmpJob,
      EmpExp:InputData.EmpExp
    });

  }

  DeleteEmp(InputId){
    alert("Sure Do you want to Delete");
    this.ApiCall.deleteData(InputId).subscribe(res=>{
      if(res){
        this.CreateForm = false;
        alert("Successfully Deleted");
        this.router.navigate(['/Home'])
        .then(() => {
          window.location.reload();
        });
      }
    });
  }

  back(){
    this.CreateForm = false;
  }

  get f(){
    return this.EmpData.controls;
  }
}
